let opcaoImagem = document.querySelectorAll('#img1,#img2,#img3');
let resultadoBG = document.getElementById('divResultadoBG');
let resultadoUp = document.getElementById('divResultadoUp');
let resultadoDown = document.getElementById('divResultadoDown');
let textBoxUp = document.getElementById('textBoxUp');
let textBoxDown = document.getElementById('textBoxDown');
let btnDownload = document.getElementById('downloadButton');
let inputImage = document.getElementById('inputUploadImage')

/* Lista de memes e seletor */

window.onload = memeListToDiv()  

function memeListToDiv (){
  
    let memes = ['/pastaMemes/BBB21-Rodolffo-01.jpg', '/pastaMemes/BBB21-ArturCarla-01.jpg' , '/pastaMemes/BBB21-Karol-01.jpg', '/pastaMemes/BBB21-Sarah-01.jpg', '/pastaMemes/BBB21-Fiuk-01.jpg', '/pastaMemes/BBB21-Lumena-02.jpg', '/pastaMemes/BBB21-Lumena-01.jpg', '/pastaMemes/BBB21-Gil-01.jpg', '/pastaMemes/BBB21-Fiuk-02.jpg'];    

for(var i = 0; i < memes.length; i++){

    document.getElementById('divMemes').innerHTML +=  
    '<div><img src="' + memes[i] + '"><button id="btnChangeMeme" class="download" data-caminho="'+ memes[i] +'" onclick="selecionarFundo()">Download</button></div>' 
  }

}

// function selecionarFundo(){
//     const sourceBtn = document.querySelectorAll('[data-caminho]')

//     var caminho = this.dataset.sourceBtn;

//     resultadoBG.style.backgroundImage = `url(${caminho})`;
// }


function selecionarFundo() {

    // let sourceBtn = document.getElementById('btnChangeMeme');
    var caminho = this.dataset.caminho;

    resultadoBG.style.backgroundImage = `url(${caminho})`;
}

opcaoImagem.forEach(function (elemento) {
    elemento.addEventListener('click', selecionarFundo);
})

/* Botao de upload de foto */

window.addEventListener('load', function(){
    document.getElementById('inputUploadImage').addEventListener('change', function(){
        if (this.files && this.files[0]) {
            var img = document.getElementById('divResultadoBG');
            img.src = URL.createObjectURL(this.files[0]);
            resultadoBG.style.backgroundImage = `url(${img.src})`;
        }
    }
    );
});

/* Inputs de textos */

textBoxUp.addEventListener('input', function () {
    resultadoUp.innerHTML = "<span class='textMeme'>" + this.value + "<span>";
})

textBoxDown.addEventListener ('input', function () {
    resultadoDown.innerHTML = "<span class='textMeme'>" + this.value + "<span>";
})


/* Download */

function download() {
    domtoimage.toPng(resultadoBG, /*{height: 800, width:800}*/)
        .then(function (urlsaida) {
            let link = document.createElement('a');
            link.download = 'saida.png';
            link.href = urlsaida;
            link.click();
        })
        .catch(function (erro) {
            alert('Erro ao baixar', erro);
        })
}